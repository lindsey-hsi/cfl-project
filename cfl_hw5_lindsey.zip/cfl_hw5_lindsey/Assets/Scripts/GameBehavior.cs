﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameBehavior : MonoBehaviour
{
    private int marbleHealth = 100;
    private int collectedGoals = 0;
    public int maxGoals = 4;
    public string labelText = "Collect all 4 goals to win!";

    public int Goals {
      get { return collectedGoals; }

      set {
        collectedGoals = value; Debug.LogFormat("Goals: {0}", collectedGoals);

        if (collectedGoals >= maxGoals) {
          labelText = "You've collected all goals!";
        } else {
          labelText = "Goal collected, only " + (maxGoals - collectedGoals) + " more to go!";
        }
      }
    }

    public int Health {
      get { return marbleHealth; }

      set {
        marbleHealth = value; Debug.LogFormat("Marble Health: {0}", marbleHealth);
      }
    }

    void OnGUI() {
      GUI.Box(new Rect(20, 20, 150, 25), "Marble Health: " + marbleHealth);
      GUI.Box(new Rect(20, 50, 150, 25), "Goals Collected: " + collectedGoals);

      GUI.Label(new Rect(Screen.width /2 - 100, Screen.height - 50, 300, 50), labelText);
    }
    // Start is called before the first frame update
    // void Start()
    // {
    //
    // }
    //
    // // Update is called once per frame
    // void Update()
    // {
    //   // Debug.LogFormat("marble health: {0}", marbleHealth);
    // }
}
