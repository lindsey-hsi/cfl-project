For extra credit our group added particle systems to each goal object that
dissapeared along with goal upon collision with the marble.